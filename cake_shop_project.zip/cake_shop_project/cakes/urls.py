# cakes/urls.py
from django.urls import path
from .views import cake_list, add_cake, edit_cake, delete_cake

urlpatterns = [
    path('cakes/', cake_list, name='cake_list'),
    path('cakes/add/', add_cake, name='add_cake'),
    path('cakes/<int:pk>/edit/', edit_cake, name='edit_cake'),
    path('cakes/<int:pk>/delete/', delete_cake, name='delete_cake'),
]
